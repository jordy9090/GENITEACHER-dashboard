import { useState } from "react";
import CalendarSection from "./components/CalendarSection";
import TodaySchedule from "./components/TodaySchedule";
import WeeklySummary from "./components/WeeklySummary";
import UpcomingEvents from "./components/UpcomingEvents";
import AddScheduleModal from "./components/AddScheduleModal";

function SchedulePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");

  const [currentDate, setCurrentDate] = useState(new Date(2025, 9, 1));

  const handlePrevMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1),
    );
  };

  const handleNextMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1),
    );
  };

  const handleDateClick = (day: number) => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + 1;
    const formattedDate = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;

    setSelectedDate(formattedDate);
    setIsModalOpen(true);
  };

  return (
    <div style={styles.container}>
      <CalendarSection
        currentDate={currentDate}
        onPrevMonth={handlePrevMonth}
        onNextMonth={handleNextMonth}
        onDateClick={handleDateClick}
      />

      <div style={styles.sidebar}>
        <TodaySchedule />
        <WeeklySummary />
        <UpcomingEvents />
      </div>

      <AddScheduleModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        selectedDate={selectedDate}
      />
    </div>
  );
}

export default SchedulePage;

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: "flex",
    backgroundColor: "#F5F7FA",
    minHeight: "100vh",
    padding: "20px",
    gap: "20px",
    fontFamily:
      '-apple-system, BlinkMacSystemFont, "Pretendard", "Apple SD Gothic Neo", "Segoe UI", sans-serif',
    color: "#333",
  },
  sidebar: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: "24px",
    minWidth: "300px",
  },
};
